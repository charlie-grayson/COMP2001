﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore.Metadata;
using COMP2001APIv3.Models;

#nullable disable

namespace COMP2001APIv3
{
    public partial class COMP2001_CGrayson : DbContext
    {
        public COMP2001_CGrayson()
        {
        }

        public COMP2001_CGrayson(DbContextOptions<COMP2001_CGrayson> options)
            : base(options)
        {
        }
        COMP2001_CGrayson Context = new COMP2001_CGrayson();

        public virtual DbSet<Password> Passwords { get; set; }
        public virtual DbSet<Session> Sessions { get; set; }
        
        public virtual DbSet<User> Users { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {

                optionsBuilder.UseSqlServer("Server=socem1.uopnet.plymouth.ac.uk;Database=COMP2001_CGrayson;User Id=CGrayson; Password=EmtF556*");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "Latin1_General_CI_AS");

            modelBuilder.Entity<Password>(entity =>
            {
                entity.ToTable("Password");

                entity.Property(e => e.PasswordId).HasColumnName("passwordID");

                entity.Property(e => e.PassChanged)
                    .HasColumnType("datetime")
                    .HasColumnName("passChanged");

                entity.Property(e => e.UserId).HasColumnName("userID");

                entity.Property(e => e.UserPassword)
                    .IsRequired()
                    .IsUnicode(false)
                    .HasColumnName("userPassword");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.Passwords)
                    .HasForeignKey(d => d.UserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Password");
            });

            modelBuilder.Entity<Session>(entity =>
            {
                entity.ToTable("Session");

                entity.Property(e => e.SessionId).HasColumnName("sessionID");

                entity.Property(e => e.SessionDateTime)
                    .HasColumnType("datetime")
                    .HasColumnName("sessionDateTime");

                entity.Property(e => e.UserId).HasColumnName("userID");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.Sessions)
                    .HasForeignKey(d => d.UserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Session");
            });

          

            modelBuilder.Entity<User>(entity =>
            {
                entity.Property(e => e.UserId).HasColumnName("userID");

                entity.Property(e => e.UserEmail)
                    .IsRequired()
                    .IsUnicode(false)
                    .HasColumnName("userEmail");

                entity.Property(e => e.UserFirstName)
                    .IsRequired()
                    .IsUnicode(false)
                    .HasColumnName("userFirstName");

                entity.Property(e => e.UserLastName)
                    .IsRequired()
                    .IsUnicode(false)
                    .HasColumnName("userLastName");

                entity.Property(e => e.UserPassword)
                    .IsRequired()
                    .IsUnicode(false)
                    .HasColumnName("userPassword");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);

        public string userReg(User user, int message)
        {

            message = Context.Database.ExecuteSqlRaw("EXEC userReg @firstName, @lastName, @email, @password, @ResponseMessage",
                new SqlParameter("@firstName", user.UserFirstName.ToString()),
                new SqlParameter("@lastName", user.UserLastName.ToString()),
                new SqlParameter("@email", user.UserEmail.ToString()),
                new SqlParameter("@password", user.UserPassword.ToString()),
                new SqlParameter("@ResponseMessage", message.ToString())
                );

            return message.ToString();
        }

        public void userUpdate(User user, int id)
        {
            Context.Database.ExecuteSqlRaw("EXEC userUpdate @userID ,@firstName, @lastName, @email, @password",
                new SqlParameter("@userID", id),
                new SqlParameter("@firstName", user.UserFirstName.ToString()),
                new SqlParameter("@lastName", user.UserLastName.ToString()),
                new SqlParameter("@email", user.UserEmail.ToString()),
                new SqlParameter("@password", user.UserPassword.ToString())
                );
        }

        public void userDelete(User user, int id)
        {
            Context.Database.ExecuteSqlRaw("EXEC userDelete @userID",
                new SqlParameter("@userID", id)
                );
        }

        public bool userValid(userValid userVal)
        {
            bool validated = false;

            Context.Database.ExecuteSqlRaw("EXEC userValid @email, @password, @valid",
                new SqlParameter("@email", userVal.UserEmail.ToString()),
                new SqlParameter("@password", userVal.UserPassword.ToString()),
                new SqlParameter("@valid", validated)
                );

            return validated;
        }
    }
}
